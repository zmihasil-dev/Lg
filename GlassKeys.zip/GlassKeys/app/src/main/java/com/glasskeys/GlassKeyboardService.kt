package com.glasskeys

import android.content.ClipboardManager
import android.content.Intent
import android.graphics.Color
import android.inputmethodservice.InputMethodService
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.util.TypedValue
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import kotlin.concurrent.thread

class GlassKeyboardService : InputMethodService() {

    private val handler = Handler(Looper.getMainLooper())

    private lateinit var root: View
    private lateinit var backdrop: BackdropView
    private lateinit var content: LinearLayout

    private var theme: Theme = Themes.get("ocean")
    private var lang = "en"

    /** 0 — буквы, 1 — символы, 2 — символы 2, 3 — буфер обмена, 4 — эмодзи */
    private var layer = 0

    /** 0 — выкл, 1 — одна заглавная, 2 — caps lock */
    private var shift = 0
    private var lastShiftTap = 0L
    private var lastSpaceTap = 0L

    private val letterKeys = mutableListOf<KeyView>()
    private var shiftKey: KeyView? = null
    private var fixKey: KeyView? = null
    private var trKey: KeyView? = null

    private var busy = false
    private var undoOriginal: String? = null
    private var undoNew: String? = null

    private lateinit var clipboard: ClipboardManager
    private val clipListener = ClipboardManager.OnPrimaryClipChangedListener { captureClip() }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    // ---------------------------------------------------------------- lifecycle

    override fun onCreate() {
        super.onCreate()
        clipboard = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.addPrimaryClipChangedListener(clipListener)
    }

    override fun onDestroy() {
        clipboard.removePrimaryClipChangedListener(clipListener)
        super.onDestroy()
    }

    override fun onEvaluateFullscreenMode() = false

    override fun onCreateInputView(): View {
        // Подложка сама является контейнером для клавиш, поэтому высота = высота клавиатуры.
        backdrop = BackdropView(this)
        backdrop.layoutParams = ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
        content = backdrop
        root = backdrop
        loadPrefs()
        render()
        return backdrop
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        loadPrefs()
        if (!restarting) {
            val cls = (info?.inputType ?: 0) and InputType.TYPE_MASK_CLASS
            layer = if (cls == InputType.TYPE_CLASS_NUMBER || cls == InputType.TYPE_CLASS_PHONE) 1 else 0
            shift = 0
        }
        if (::root.isInitialized) {
            render()
            updateAutoShift()
            applyBlur()
        }
        captureClip()
    }

    override fun onUpdateSelection(
        oldSelStart: Int, oldSelEnd: Int, newSelStart: Int, newSelEnd: Int,
        candidatesStart: Int, candidatesEnd: Int
    ) {
        super.onUpdateSelection(oldSelStart, oldSelEnd, newSelStart, newSelEnd, candidatesStart, candidatesEnd)
        updateAutoShift()
    }

    private fun loadPrefs() {
        theme = Themes.get(Prefs.theme(this))
        lang = Prefs.currentLang(this)
    }

    /** Реальное размытие фона за окном клавиатуры (Android 12+), если подложка полупрозрачная. */
    private fun applyBlur() {
        if (Build.VERSION.SDK_INT < 31) return
        try {
            val w = window?.window ?: return
            if (Prefs.opacity(this) < 100) {
                w.addFlags(WindowManager.LayoutParams.FLAG_BLUR_BEHIND)
                val lp = w.attributes
                lp.blurBehindRadius = 40
                w.attributes = lp
            } else {
                w.clearFlags(WindowManager.LayoutParams.FLAG_BLUR_BEHIND)
            }
        } catch (_: Throwable) {
        }
    }

    // ---------------------------------------------------------------- rendering

    private fun panelHeight() = dp(Prefs.keyHeight(this) * 4 + 6)

    private fun render() {
        if (!::root.isInitialized) return
        backdrop.apply(theme, Prefs.opacity(this))
        content.removeAllViews()
        letterKeys.clear()
        shiftKey = null
        content.addView(toolbar())
        when (layer) {
            3 -> content.addView(clipPanel())
            4 -> content.addView(emojiPanel())
            else -> content.addView(keysPanel())
        }
    }

    private fun rowParams(h: Int) = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, h)

    private fun keyParams(weight: Float): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, weight).also {
            it.setMargins(dp(2), dp(3), dp(2), dp(3))
        }

    private fun newRow(h: Int): LinearLayout =
        LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = rowParams(h)
        }

    private fun spacer(weight: Float): View =
        View(this).apply { layoutParams = LinearLayout.LayoutParams(0, 1, weight) }

    private fun makeKey(
        label: String,
        weight: Float,
        hint: String? = null,
        accent: Boolean = false,
        repeat: Boolean = false,
        size: Float = 20f,
        onTap: () -> Unit
    ): KeyView {
        val v = KeyView(this, label, hint, theme.text, size)
        v.background = Glass.bg(this, theme, 10f, accent)
        v.layoutParams = keyParams(weight)
        attachTouch(v, repeat, hint, onTap)
        return v
    }

    private fun attachTouch(v: View, repeat: Boolean, hint: String?, onTap: () -> Unit) {
        var consumed = false
        var rep: Runnable? = null
        var lp: Runnable? = null

        fun cancel() {
            rep?.let { handler.removeCallbacks(it) }
            lp?.let { handler.removeCallbacks(it) }
            rep = null
            lp = null
        }

        fun release(view: View) {
            view.isPressed = false
            view.scaleX = 1f
            view.scaleY = 1f
        }

        v.setOnTouchListener { view, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    view.isPressed = true
                    view.scaleX = 0.95f
                    view.scaleY = 0.95f
                    buzz(view)
                    consumed = false
                    if (repeat) {
                        onTap()
                        val r = object : Runnable {
                            override fun run() {
                                onTap()
                                handler.postDelayed(this, 45)
                            }
                        }
                        rep = r
                        handler.postDelayed(r, 380)
                    } else if (hint != null) {
                        val r = Runnable {
                            consumed = true
                            commit(hint)
                        }
                        lp = r
                        handler.postDelayed(r, 360)
                    }
                }
                MotionEvent.ACTION_UP -> {
                    release(view)
                    cancel()
                    if (!repeat && !consumed) onTap()
                }
                MotionEvent.ACTION_CANCEL -> {
                    release(view)
                    cancel()
                }
                MotionEvent.ACTION_MOVE -> {
                    if (ev.x < 0 || ev.y < 0 || ev.x > view.width || ev.y > view.height) {
                        release(view)
                        cancel()
                        consumed = true
                    }
                }
            }
            true
        }
    }

    private fun buzz(v: View) {
        if (Prefs.haptic(this)) v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
    }

    // ---------------------------------------------------------------- toolbar

    private fun toolbar(): View {
        val row = newRow(dp(42))
        row.setPadding(dp(3), dp(4), dp(3), 0)

        row.addView(makeKey("📋", 1f, size = 18f) { layer = if (layer == 3) 0 else 3; render() })
        fixKey = makeKey("✨", 1f, size = 18f) { transform(fix = true) }
        row.addView(fixKey)
        trKey = makeKey("🌐", 1f, size = 18f) { transform(fix = false) }
        row.addView(trKey)
        row.addView(makeKey("😊", 1f, size = 18f) { layer = if (layer == 4) 0 else 4; render() })
        row.addView(makeKey("↩", 1f, size = 18f) { undo() })
        row.addView(makeKey("⚙", 1f, size = 18f) {
            startActivity(Intent(this, SettingsActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        })
        return row
    }

    // ---------------------------------------------------------------- key panels

    private fun keysPanel(): View {
        val kh = dp(Prefs.keyHeight(this))
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(3), dp(2), dp(3), dp(4))
        }
        if (layer == 0) buildLetters(box, kh) else buildSymbols(box, kh)
        return box
    }

    private fun letterKey(ch: String, hint: String?): KeyView {
        val k = makeKey(ch, 1f, hint) {
            val out = if (shift != 0) ch.uppercase() else ch
            commit(out)
            if (shift == 1) {
                shift = 0
                updateShiftUi()
            }
        }
        k.tag = ch
        letterKeys.add(k)
        return k
    }

    private fun buildLetters(box: LinearLayout, kh: Int) {
        val rows = Layouts.rows(lang)
        val digits = "1234567890"

        // ряд 1
        val r1 = newRow(kh)
        rows[0].forEachIndexed { i, ch ->
            val hint = when {
                i < 10 -> digits[i].toString()
                lang == "ru" && i == 10 -> "ё"
                else -> null
            }
            r1.addView(letterKey(ch.toString(), hint))
        }
        box.addView(r1)

        // ряд 2
        val r2 = newRow(kh)
        val pad2 = (rows[0].length - rows[1].length) / 2f
        if (pad2 > 0) r2.addView(spacer(pad2))
        rows[1].forEach { r2.addView(letterKey(it.toString(), null)) }
        if (pad2 > 0) r2.addView(spacer(pad2))
        box.addView(r2)

        // ряд 3: shift + буквы + backspace
        val r3 = newRow(kh)
        val side = ((rows[0].length - rows[2].length) / 2f).coerceIn(1.2f, 2f)
        val sk = makeKey("⇧", side, size = 20f) { onShiftTap() }
        shiftKey = sk
        r3.addView(sk)
        rows[2].forEach { r3.addView(letterKey(it.toString(), null)) }
        r3.addView(makeKey("⌫", side, repeat = true) { backspace() })
        box.addView(r3)

        // ряд 4
        val r4 = newRow(kh)
        r4.addView(makeKey("?123", 1.5f, size = 15f) { layer = 1; render() })
        r4.addView(makeKey(lang.uppercase(), 1.1f, size = 14f) { cycleLang() })
        r4.addView(makeKey(",", 1f, "?") { commit(",") })
        r4.addView(makeKey(Layouts.names[lang] ?: "", 4f, size = 13f) { onSpace() })
        r4.addView(makeKey(".", 1f, "!") { commit(".") })
        r4.addView(makeKey(enterLabel(), 1.5f, accent = true) { enter() })
        box.addView(r4)

        updateShiftUi()
    }

    private fun buildSymbols(box: LinearLayout, kh: Int) {
        val r1: String
        val r2: String
        val r3: String
        if (layer == 1) {
            r1 = "1234567890"
            r2 = "@#\$%&-+()/"
            r3 = "*\"':;!?"
        } else {
            r1 = "~`|•√π÷×¶∆"
            r2 = "€£¥₽^°={}\\"
            r3 = "©®™[]<>"
        }
        fun plain(str: String): LinearLayout {
            val r = newRow(kh)
            str.forEach { ch -> r.addView(makeKey(ch.toString(), 1f) { commit(ch.toString()) }) }
            return r
        }
        box.addView(plain(r1))
        box.addView(plain(r2))
        val row3 = newRow(kh)
        row3.addView(makeKey(if (layer == 1) "=\\<" else "123", 1.5f, size = 15f) {
            layer = if (layer == 1) 2 else 1
            render()
        })
        r3.forEach { ch -> row3.addView(makeKey(ch.toString(), 1f) { commit(ch.toString()) }) }
        row3.addView(makeKey("⌫", 1.5f, repeat = true) { backspace() })
        box.addView(row3)

        val r4 = newRow(kh)
        r4.addView(makeKey("ABC", 1.5f, size = 15f) { layer = 0; render() })
        r4.addView(makeKey(",", 1f) { commit(",") })
        r4.addView(makeKey(Layouts.names[lang] ?: "", 4f, size = 13f) { onSpace() })
        r4.addView(makeKey(".", 1f) { commit(".") })
        r4.addView(makeKey(enterLabel(), 1.5f, accent = true) { enter() })
        box.addView(r4)
    }

    // ---------------------------------------------------------------- clipboard panel

    private fun glassText(
        text: String,
        sizeSp: Float,
        weight: Float? = null,
        onClick: (() -> Unit)? = null
    ): TextView {
        return TextView(this).apply {
            this.text = text
            setTextColor(theme.text)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, sizeSp)
            gravity = Gravity.CENTER_VERTICAL
            background = Glass.bg(this@GlassKeyboardService, theme, 10f)
            setPadding(dp(12), dp(8), dp(12), dp(8))
            layoutParams = if (weight != null)
                LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, weight).also {
                    it.setMargins(dp(3), dp(3), dp(3), dp(3))
                }
            else
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                    .also { it.setMargins(dp(3), dp(3), dp(3), dp(3)) }
            if (onClick != null) setOnClickListener { buzz(it); onClick() }
        }
    }

    private fun clipPanel(): View {
        val wrap = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = rowParams(panelHeight())
            setPadding(dp(5), dp(4), dp(5), dp(4))
        }
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        head.addView(glassText("ABC", 15f) { layer = 0; render() })
        head.addView(TextView(this).apply {
            text = "Буфер обмена"
            setTextColor(theme.text)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f)
        })
        head.addView(glassText("Очистить", 14f) {
            val keep = ClipStore.load(this).filter { it.pinned }
            ClipStore.save(this, keep)
            render()
        })
        wrap.addView(head)

        val list = ClipStore.load(this).sortedByDescending { it.pinned }
        val sv = ScrollView(this)
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        if (list.isEmpty()) {
            col.addView(TextView(this).apply {
                text = if (Prefs.clipEnabled(this@GlassKeyboardService))
                    "Пока пусто — скопируйте любой текст, и он появится здесь."
                else "История буфера выключена в настройках."
                setTextColor(theme.text)
                alpha = 0.7f
                gravity = Gravity.CENTER
                setPadding(dp(16), dp(32), dp(16), dp(16))
            })
        }
        for (item in list) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            val t = glassText(item.text.replace("\n", " ⏎ "), 14f, 1f) {
                commit(item.text)
                layer = 0
                render()
            }
            t.maxLines = 2
            t.ellipsize = android.text.TextUtils.TruncateAt.END
            row.addView(t)
            row.addView(glassText(if (item.pinned) "📌" else "📍", 14f) {
                val all = ClipStore.load(this)
                all.firstOrNull { it.text == item.text }?.pinned = !item.pinned
                ClipStore.save(this, all)
                render()
            })
            row.addView(glassText("✕", 14f) {
                val all = ClipStore.load(this)
                all.removeAll { it.text == item.text }
                ClipStore.save(this, all)
                render()
            })
            col.addView(row)
        }
        sv.addView(col)
        wrap.addView(sv, LinearLayout.LayoutParams(-1, 0, 1f))
        return wrap
    }

    // ---------------------------------------------------------------- emoji panel

    private val emojis = ("😀 😃 😄 😁 😆 😅 😂 🤣 😊 😇 🙂 😉 😍 🥰 😘 😋 😛 😜 🤪 😎 🤩 🥳 😏 😒 😞 😔 😟 😕 🙁 😣 " +
            "😢 😭 😤 😠 😡 🤯 😳 🥵 🥶 😱 😨 😰 🤗 🤔 🤭 🤫 😐 😑 😶 🙄 😬 😴 🤤 😷 🤒 🤕 🤢 🤮 🥴 😈 " +
            "💀 👻 🤡 💩 👍 👎 👌 ✌️ 🤞 🤝 👏 🙌 🙏 💪 👋 🤙 👀 🧠 ❤️ 🧡 💛 💚 💙 💜 🖤 💔 ✨ 🔥 💯 ⭐ 🎉 " +
            "🎁 🎂 ☕ 🍕 🍔 🍺 🌹 ☀️ 🌙 ⚡ 🌈 ✅ ❌ ❗ ❓ 💬 📌 📞 💻 📱 🚗 ✈️ 🏠").split(" ")

    private fun emojiPanel(): View {
        val wrap = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = rowParams(panelHeight())
            setPadding(dp(5), dp(4), dp(5), dp(4))
        }
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        head.addView(glassText("ABC", 15f) { layer = 0; render() })
        head.addView(View(this).apply { layoutParams = LinearLayout.LayoutParams(0, 1, 1f) })
        head.addView(glassText("⌫", 16f) { backspace() })
        wrap.addView(head)

        val sv = ScrollView(this)
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        emojis.chunked(8).forEach { chunk ->
            val r = newRow(dp(46))
            chunk.forEach { e ->
                r.addView(TextView(this).apply {
                    text = e
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 24f)
                    gravity = Gravity.CENTER
                    layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f)
                    setOnClickListener { buzz(it); commit(e) }
                })
            }
            repeat(8 - chunk.size) { r.addView(spacer(1f)) }
            col.addView(r)
        }
        sv.addView(col)
        wrap.addView(sv, LinearLayout.LayoutParams(-1, 0, 1f))
        return wrap
    }

    // ---------------------------------------------------------------- typing actions

    private fun commit(s: String) {
        currentInputConnection?.commitText(s, 1)
    }

    private fun backspace() {
        val ic = currentInputConnection ?: return
        val sel = ic.getSelectedText(0)
        if (!sel.isNullOrEmpty()) ic.commitText("", 1)
        else sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL)
    }

    private fun onSpace() {
        val now = System.currentTimeMillis()
        val ic = currentInputConnection ?: return
        if (now - lastSpaceTap < 400) {
            val before = ic.getTextBeforeCursor(2, 0)?.toString() ?: ""
            if (before.length == 2 && before[1] == ' ' && (before[0].isLetterOrDigit())) {
                ic.deleteSurroundingText(1, 0)
                ic.commitText(". ", 1)
                lastSpaceTap = 0
                return
            }
        }
        lastSpaceTap = now
        ic.commitText(" ", 1)
    }

    private fun enterAction(): Int {
        val ei = currentInputEditorInfo ?: return EditorInfo.IME_ACTION_NONE
        if (ei.imeOptions and EditorInfo.IME_FLAG_NO_ENTER_ACTION != 0) return EditorInfo.IME_ACTION_NONE
        return ei.imeOptions and EditorInfo.IME_MASK_ACTION
    }

    private fun enterLabel(): String = when (enterAction()) {
        EditorInfo.IME_ACTION_SEND -> "➤"
        EditorInfo.IME_ACTION_SEARCH -> "🔍"
        EditorInfo.IME_ACTION_GO, EditorInfo.IME_ACTION_NEXT -> "→"
        EditorInfo.IME_ACTION_DONE -> "✓"
        else -> "⏎"
    }

    private fun enter() {
        val a = enterAction()
        if (a == EditorInfo.IME_ACTION_NONE || a == EditorInfo.IME_ACTION_UNSPECIFIED) {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER)
        } else {
            currentInputConnection?.performEditorAction(a)
        }
    }

    private fun cycleLang() {
        val l = Prefs.langs(this)
        if (l.size > 1) {
            lang = l[(l.indexOf(lang) + 1) % l.size]
            Prefs.setCurrentLang(this, lang)
            render()
            updateAutoShift()
        } else {
            toast("Добавьте языки в настройках (⚙)")
        }
    }

    // ---------------------------------------------------------------- shift

    private fun onShiftTap() {
        val now = System.currentTimeMillis()
        shift = if (now - lastShiftTap < 350) 2 else if (shift == 0) 1 else 0
        lastShiftTap = now
        updateShiftUi()
    }

    private fun updateAutoShift() {
        if (!::root.isInitialized || layer != 0) return
        if (!Prefs.autoCap(this) || shift == 2) return
        val ei = currentInputEditorInfo ?: return
        val caps = currentInputConnection?.getCursorCapsMode(ei.inputType) ?: 0
        val want = if (caps != 0) 1 else 0
        if (want != shift) {
            shift = want
            updateShiftUi()
        }
    }

    private fun updateShiftUi() {
        for (k in letterKeys) {
            val base = k.tag as String
            k.label = if (shift != 0) base.uppercase() else base
            k.invalidate()
        }
        shiftKey?.let {
            it.label = when (shift) {
                1 -> "⬆"
                2 -> "⇪"
                else -> "⇧"
            }
            it.background = Glass.bg(this, theme, 10f, shift != 0)
            it.invalidate()
        }
    }

    // ---------------------------------------------------------------- clipboard capture

    private fun captureClip() {
        if (!Prefs.clipEnabled(this)) return
        try {
            val clip = clipboard.primaryClip ?: return
            if (clip.itemCount == 0) return
            if (Build.VERSION.SDK_INT >= 33 &&
                clip.description.extras?.getBoolean("android.content.extra.IS_SENSITIVE") == true
            ) return
            val t = clip.getItemAt(0).coerceToText(this)?.toString() ?: return
            if (t.isBlank() || t.length > 5000) return
            val cur = ClipStore.load(this)
            if (cur.firstOrNull()?.text == t) return
            ClipStore.add(this, t)
            if (layer == 3) render()
        } catch (_: Exception) {
        }
    }

    // ---------------------------------------------------------------- fix / translate

    private fun isPasswordField(): Boolean {
        val t = currentInputEditorInfo?.inputType ?: return false
        val cls = t and InputType.TYPE_MASK_CLASS
        val v = t and InputType.TYPE_MASK_VARIATION
        return (cls == InputType.TYPE_CLASS_TEXT && (v == InputType.TYPE_TEXT_VARIATION_PASSWORD ||
                v == InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD ||
                v == InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD)) ||
                (cls == InputType.TYPE_CLASS_NUMBER && v == InputType.TYPE_NUMBER_VARIATION_PASSWORD)
    }

    private fun transform(fix: Boolean) {
        if (busy) return
        val ic = currentInputConnection ?: return
        if (isPasswordField()) {
            toast("В полях пароля отключено")
            return
        }
        val selected = ic.getSelectedText(0)?.toString()
        val hasSel = !selected.isNullOrEmpty()
        val before = if (hasSel) "" else ic.getTextBeforeCursor(3000, 0)?.toString() ?: ""
        val after = if (hasSel) "" else ic.getTextAfterCursor(3000, 0)?.toString() ?: ""
        val original = if (hasSel) selected!! else before + after
        if (original.isBlank()) {
            toast("Сначала введите текст")
            return
        }

        val src = Net.detectSource(original, lang)
        var tgt = Prefs.target(this)
        if (tgt == src) {
            tgt = Prefs.langs(this).firstOrNull { it != src } ?: if (src == "en") "ru" else "en"
        }
        val ltLang = run {
            val cyr = Net.detectSource(original, lang)
            if (cyr == lang) Layouts.ltTag(lang) else Layouts.ltTag(cyr).takeIf { it != "auto" } ?: "auto"
        }

        busy = true
        val key = if (fix) fixKey else trKey
        val oldLabel = key?.label
        key?.label = "⏳"
        key?.invalidate()

        thread {
            val result: String? = try {
                if (fix) Net.fix(original, ltLang) else Net.translate(original, src, tgt)
            } catch (e: Exception) {
                null
            }
            handler.post {
                busy = false
                key?.label = oldLabel ?: ""
                key?.invalidate()
                if (result == null) {
                    toast("Нет сети или сервис недоступен")
                    return@post
                }
                if (result == original) {
                    toast(if (fix) "Ошибок не найдено" else "Перевод совпал с оригиналом")
                    return@post
                }
                val ic2 = currentInputConnection ?: return@post
                ic2.beginBatchEdit()
                if (hasSel) {
                    ic2.commitText(result, 1)
                } else {
                    val b2 = ic2.getTextBeforeCursor(3000, 0)?.toString() ?: ""
                    val a2 = ic2.getTextAfterCursor(3000, 0)?.toString() ?: ""
                    if (b2 + a2 != original) {
                        ic2.endBatchEdit()
                        toast("Текст изменился — повторите")
                        return@post
                    }
                    ic2.deleteSurroundingText(b2.length, a2.length)
                    ic2.commitText(result, 1)
                }
                ic2.endBatchEdit()
                undoOriginal = original
                undoNew = result
                toast(if (fix) "Исправлено · ↩ отменить" else "Переведено ($src → $tgt) · ↩ отменить")
            }
        }
    }

    private fun undo() {
        val o = undoOriginal
        val n = undoNew
        if (o == null || n == null) {
            toast("Нечего отменять")
            return
        }
        val ic = currentInputConnection ?: return
        ic.beginBatchEdit()
        ic.deleteSurroundingText(n.length, 0)
        ic.commitText(o, 1)
        ic.endBatchEdit()
        undoOriginal = null
        undoNew = null
    }

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }
}
